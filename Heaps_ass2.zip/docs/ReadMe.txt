Benedict Heaps
A00528292
bheaps99@gmail.com

Everything is complete

Major Challenges:
-unable to use api as name for service in docker-compose
-unable to host https for the api in docker-compose
-unable to access http in Blazor for pages //solved by adding @using System.Net.Http to the top of razor pages

All major challenges solved

Students on the landing page are sorted by BCIT student number

please run: docker-compose up
http://localhost:8888 should be active